export default class Car{
    constructor(carno,carname,price){
        this.rownumber=rownumebr;
        this.carno=carno;
        this.carname=carname;
        this.price=price;
    }
}